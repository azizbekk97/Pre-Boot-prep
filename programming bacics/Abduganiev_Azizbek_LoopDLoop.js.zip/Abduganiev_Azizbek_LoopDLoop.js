function candy(arr) {
    for (var i = 0; i < arr.length; i++){
        if (arr[i] == 2){
            console.log("give a candy")
        } else if (arr[i] == 6) {
            break
        }

    }
}