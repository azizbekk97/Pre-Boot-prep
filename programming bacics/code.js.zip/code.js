// YOUR COMMENT HERE - sets variable to 0?
var likeCount = 0;
// YOUR COMMENT HERE - just calls the function
function increaseLikes() {
    // YOUR COMMENT HERE - adds 1 to the variable
    likeCount = likeCount + 1