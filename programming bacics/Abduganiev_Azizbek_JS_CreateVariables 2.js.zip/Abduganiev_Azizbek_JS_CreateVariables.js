// variable for our program to determine if a guest can ride  the coaster
function rollercoaster(height, age) {



var min_height = 42;
var min_age = 10; 

if (height > min_height) {
    console.log("Get on that ride kido!")
}

if (height >= 42 && age >= 10) {
    console.log("Get on that ride kido!")
} 

if (height >= 42 || age >= 10) {
    console.log("Get on that ride kido!")
}

