// variable for our program to determine if a guest can ride  the coaster
var minimum_height = 42;
var minimum_age = 10;
